// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>


#include "dictionary.h"

// Represents number of buckets in a hash table
#define N 26

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Represents a hash table
// N is 26, 1 bucket for each letter in English alphabet
node *hashtable[N];

// Hashes word to a number between 0 and 25, inclusive, based on its first letter
unsigned int hash(const char *word)
{
    return tolower(word[0]) - 'a';
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    // Initialize hash table
    // creates array of size 26 and set it to NULL value
    for (int i = 0; i < N; i++)
    {
        hashtable[i] = NULL;
    }

    // Open dictionary
    FILE *file = fopen(dictionary, "r");
    if (file == NULL)
    {
        unload();
        return false;
    }

    // Buffer for a word
    char word[LENGTH + 1];
    // load words from the dictionary
    while (fscanf(file, "%s", word) != EOF)
    {
        // TODO
        // hash the word to be used as index of the hashtable
        int index = hash(word) % 26;

        // dynamically allocate space for a new node
        node *newnode = malloc(sizeof(node));
        // check to make sure we didn't run out of memory
        if (newnode == NULL)
        {
            exit(1);
        }
        // initialize the node's word field
        strcpy(newnode->word, word);
        // initialize the node's next(pointer) field
        newnode->next = NULL;

        if (hashtable[index] == NULL)
        {
            // add the head node
            hashtable[index] = newnode;
        }
        else if (hashtable[index] != NULL)
        {
            // to chain the node to the head node, add the newnode at the beginning of the hash
            // set the pointer of the newnode to the head of the hashtable[index]
            newnode->next = hashtable[index];
            // point the hashtable[index] to the newnode
            hashtable[index] = newnode;
        }
    }

    // Close dictionary
    fclose(file);

    // Indicate success
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    unsigned int nwords = 0;
    // iterate the hashtable
    for (int i = 0; i < N; i++)
    {
        // traverse linkedlist in each hash
        node *temp = hashtable[i];

        while (temp != NULL)
        {
            temp = temp->next;
            nwords++;
        }
    }
    if (nwords <= 0)
    {
        return 0;
    }
    else
    {
        // printf("NO. OF WORDS IN THE DICTIONARY: %i\n", nwords);
        return nwords;
    }
}

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    // TODO
    int sizeofword = strlen(word) + 1;

    char wordtocheck[sizeofword];
    wordtocheck[sizeofword] = '\0';

    // copy word into wordcheck
    for (int i = 0; i < sizeofword; i++)
    {
        wordtocheck[i] = word[i];
    }

    // iterate the hashtable
    for (int i = 0; i < N; i++)
    {
        // traverse linkedlist in each hash
        node *temp = hashtable[i];

        while (temp != NULL)
        {
            if (strcasecmp(wordtocheck, temp->word) == 0)
            {
                // printf("correct words: %s\n", wordtocheck);
                // free(wordtocheck);
                return true;
            }
            temp = temp->next;
        }
    }
    // free(wordtocheck);
    return false;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    // TODO
    // iterate the hashtable
    for (int i = 0; i < N; i++)
    {
        // traverse linkedlist in each hash
        node *cursor = hashtable[i];

        while (cursor != NULL)
        {
            node *temp = cursor;
            cursor = cursor->next;
            free(temp);
        }
        hashtable[i] = NULL;
    }
    // check if all elements in hashtable is NULL
    int nullval = 0;

    for (int i = 0; i < N; i++)
    {
        if (hashtable[i] == NULL)
        {
            // printf("null bucket: %i\n", i);
            nullval++;
        }
    }
    // printf("\nDELETED BUCKETS: %i\n",nullval);
    if (nullval == 26)
    {
        return true;
    }
    return false;
}

// make speller
// ./speller dictionaries/small texts/cat.txt
// help50 valgrind ./speller dictionaries/large texts/cat.txt

