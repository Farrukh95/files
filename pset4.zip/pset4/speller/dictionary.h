// Declares a dictionary's functionality
// ensures that claing will only compile this once when you use #include
#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdbool.h>

// Maximum length for a word
// (e.g., pneumonoultramicroscopicsilicovolcanoconiosis)
// find and replace trick. find LENGTH, replace it with value 45
#define LENGTH 45

// Prototypes
// const = constant
bool load(const char *dictionary);
unsigned int size(void);
bool check(const char *word);
bool unload(void);

#endif // DICTIONARY_H
